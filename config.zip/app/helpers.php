<?php
function furl($url){
    return url('/storage/'.$url);
}
function types($arg)
{
    $types = [
        "در حال بررسی" => '',
        "در حال انجام" => '',
        "انجام شد" => 'btn-gradient',
        "دریافت شد" => 'btn-off',
        "جواب داده نشد" => 'btn-off',
        "جواب داده شد" => 'btn-gradient',
        "not completed" => 'btn-gray',
        "not answered"=>'btn-off',
        "completed" => 'btn-gradient'


    ];
    return $types[$arg];
}
