<div class="form-group">
    <input class="form-control" type="text" name="{{$name}}" placeholder="{{$ph}}">
</div>
