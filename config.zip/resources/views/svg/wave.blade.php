<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1020 292.33">
    <defs>
        <style>.cls-77{fill:url(#linear-gradient-77);}.cls-88{fill:url(#linear-gradient-88);}</style>
        <linearGradient id="linear-gradient-77" y1="146.17" x2="1020" y2="146.17" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#fff" stop-opacity="0.3"/>
            <stop offset="0.27" stop-color="#fff" stop-opacity="0.31"/>
            <stop offset="0.48" stop-color="#fff" stop-opacity="0.35"/>
            <stop offset="0.68" stop-color="#fff" stop-opacity="0.42"/>
            <stop offset="0.86" stop-color="#fff" stop-opacity="0.51"/>
            <stop offset="1" stop-color="#fff" stop-opacity="0.6"/>
        </linearGradient>
        <linearGradient id="linear-gradient-88" y1="146.59" y2="146.59" xlink:href="#linear-gradient-77"/>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home_P" data-name="Home P">
            <path class="cls-77"
                  d="M1020,74.68V264a28.35,28.35,0,0,1-28.35,28.35H28.35A28.35,28.35,0,0,1,0,264V68.27C170.05-4.58,364.38-20,543.62,26.13c85.08,21.88,166.7,57,253.12,72.75,74.92,13.63,157,10.6,222.8-25.54Z"/>
            <path class="cls-88"
                  d="M1020,50V263a28.35,28.35,0,0,1-28.35,28.35H28.35A28.35,28.35,0,0,1,0,263V1.84A1646.07,1646.07,0,0,1,216.79,26.13c121,21.88,237,57,359.83,72.75C683.12,112.51,758.55,128.8,852,94.33,875.08,85.82,966.65,53.92,1020,50Z"/>
        </g>
    </g>
</svg>
