<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 137.01 30.88">
    <defs>
        <style>.cls-1 {
                fill: #333;
            }

            .cls-2 {
                fill: url(#New_Gradient_Swatch_1);
            }

            .cls-3 {
                fill: url(#New_Gradient_Swatch_1-2);
            }</style>
        <linearGradient id="New_Gradient_Swatch_1" x1="26.46" x2="26.46" y2="30.88" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#92278f"/>
            <stop offset="0.2" stop-color="#8f2a91"/>
            <stop offset="0.37" stop-color="#853398"/>
            <stop offset="0.52" stop-color="#7443a3"/>
            <stop offset="0.66" stop-color="#5c59b2"/>
            <stop offset="0.8" stop-color="#3d75c7"/>
            <stop offset="0.93" stop-color="#1898df"/>
            <stop offset="1" stop-color="#00aeef"/>
        </linearGradient>
        <linearGradient id="New_Gradient_Swatch_1-2" x1="2.94" y1="0" x2="2.94" y2="30.88"
                        xlink:href="#New_Gradient_Swatch_1"/>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home_P" data-name="Home P">
            <path class="cls-1"
                  d="M14.7,30.88A3,3,0,0,1,12,29.19L.28,4.2A2.95,2.95,0,0,1,5.61,1.69L14.7,21,23.8,1.69A2.95,2.95,0,0,1,29.13,4.2l-11.76,25A3,3,0,0,1,14.7,30.88Z"/>
            <path class="cls-2"
                  d="M26.46,30.88a2.94,2.94,0,0,1-2.94-2.94v-25a2.95,2.95,0,0,1,5.89,0v25A2.94,2.94,0,0,1,26.46,30.88Z"/>
            <path class="cls-3"
                  d="M2.94,30.88A2.94,2.94,0,0,1,0,27.94v-25a2.95,2.95,0,0,1,5.89,0v25A2.94,2.94,0,0,1,2.94,30.88Z"/>
            <path class="cls-1"
                  d="M104.32,30.88a11.15,11.15,0,1,1,6.17-20.43,2.8,2.8,0,0,1-3.1,4.66,5.55,5.55,0,1,0,0,9.26,2.8,2.8,0,0,1,3.08,4.68A11.1,11.1,0,0,1,104.32,30.88Z"/>
            <path class="cls-1"
                  d="M86.24,30.88a2.8,2.8,0,0,1-2.8-2.8V11.37a2.8,2.8,0,0,1,5.6,0V28.08A2.8,2.8,0,0,1,86.24,30.88Z"/>
            <path class="cls-1"
                  d="M134.21,30.88H117.49A2.81,2.81,0,0,1,115,26.83l8.37-16.71a2.79,2.79,0,0,1,5,0l8.37,16.71a2.81,2.81,0,0,1-2.51,4.05ZM122,25.28h7.66l-3.83-7.65Z"/>
            <path class="cls-1"
                  d="M52.73,30.88H36a2.81,2.81,0,0,1-2.51-4.05l8.37-16.71a2.8,2.8,0,0,1,5,0l8.36,16.71a2.8,2.8,0,0,1-2.51,4.05Zm-12.19-5.6H48.2l-3.83-7.65Z"/>
            <path class="cls-1"
                  d="M79.32,19.77a11.31,11.31,0,0,1-.36,2.8A11.11,11.11,0,1,1,68.2,8.65h5.46a2.8,2.8,0,0,1,0,5.6H68.2A5.52,5.52,0,1,0,73,22.57H70.84a2.8,2.8,0,0,1,0-5.59h5.68A2.8,2.8,0,0,1,79.32,19.77Z"/>
        </g>
    </g>
</svg>
