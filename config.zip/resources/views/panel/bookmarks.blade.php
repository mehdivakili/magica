@extends('layouts.app')
@section('content')
    <div class="bookmark-panel available style-div" style="padding-left: 3px; min-height: 535px">
    @include('widget.div-style-scroll-start',['classes'=>'column','height_depend'=>'available','height_px'=>20, 'bg'=>'#00000000', 'info'=>false,'name'=>'column'])
    <ul>
        @foreach($arts as $art)
            <li class="art-con">
                <a href="{{url('art/'.$art->name)}}">
                    <img class="img-fluid" src="{{furl($art->pro_image_link)}}">
                </a>
                <div class="banner-content">
                    <button class="icon" onclick="bookmark('{{url('bookmark/'.$art->name)}}')">@include('svg.bookmark-white')</button>
                </div>
            </li>
        @endforeach
    </ul>
    </div>
    @include('widget.div-style-end')
    <script>
        function bookmark(url) {
            $.ajax({
                type: 'GET',
                url: url,
                success: function (data) {
                }
            });

        }
    </script>
@stop
