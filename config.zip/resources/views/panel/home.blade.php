@extends('layouts.app')

@section('content')
    <div class="home-div">
        <div class="other">
            <div class="brand style-div available" style="min-height: 300px">

                <div id="wave">@include('svg.wave')</div>
                @include('svg.magica_m')
                <p>{!!__('Magica, a system for everyone')!!}</p>

            </div>
            <div class="d-flex" style="height: 260px">
                @include('widget.div-style-start',['classes'=>'account-div','title'=>__('Account type')])
                    <div class="style-div acount">
                        <p>{{__($user->type)}}</p>
                    </div>
                <a class="btn btn-gradient" href="{{url('upgradeAccount')}}">{{__('upgrade account')}}</a>
                @include('widget.div-style-end')
                @include('widget.div-style-scroll-start',['classes'=>'ticket-div','title'=>__('Notifications')])
                @empty($user->tickets)
                    <p>asdfkajlasjkdaslf</p>
                @else
                    <ul class="tickets" style="height: 170px;">
                        @foreach($user->tickets as $ticket)
                            <li data-toggle="modal" data-target="#ticket{{$loop->index}}" class="{{types(__($ticket->status))}} justify-content-between"><p>{{$ticket->title}}</p><span><span>{{__($ticket->status)}}</span><i class="fa fa-times" aria-hidden="true"></i></span></li>


                            <div class="modal fade" id="ticket{{$loop->index}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered " role="document">

                                    <div class="modal-content style-div">
                                        <div class="style-div-extra-20">
                                            <div class="modal-body">
                                                <p class="title">{{$ticket->title}}</p>
                                                <p class="description">{{$ticket->description}}</p>
{{--                                                <div class="style-div-extra"> <div class="style-div-extra"> <p class="answer style-div">@if(!empty($ticket->answer)){{$ticket->answer}}@else{{__("not answered")}}@endif</p></div></div>--}}
                                                <div class="d-flex justify-content-end" style="width: 100%">
                                                    <button class="btn btn-gray" data-dismiss="modal">{{__("Close")}}</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                            </div>
                        @endforeach
                    </ul>
                @endempty
                @include('widget.div-style-end')
            </div>
        </div>
        @include('widget.div-style-scroll-start',['classes'=>'orders-div','title'=>__('Your orders'),"height_depend"=>'brand',"height_px"=>260])
        @empty($user->orders)
            <p>asdfkajlasjkdaslf</p>
        @else
            <ul class="orders ">
                @foreach($user->orders as $order)
                    <li class="{{types(__($order->status))}} justify-content-between">@empty($order->order_image)@else <a class="d-flex justify-content-between" href="{{furl($order->order_image)}}"> @endempty<p>{{$order->name}}</p><span><span>{{__($order->status)}}</span><i class="fa fa-times" aria-hidden="true"></i></span>@empty($order->order_image)@else </a> @endempty</li>
                @endforeach
            </ul>

        @endempty
        @include('widget.div-style-end')

    </div>
@endsection
