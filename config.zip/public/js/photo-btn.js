$(document).ready(function () {


    var first = $('.btn[first]')
    first.addClass("btn-gradient-no-width");
    filterSelection(first.attr("category"))

// Execute the function and show all columns
    function filterSelection(c) {
        var x, i;
        x = document.getElementsByClassName("column");
        for (i = 0; i < x.length; i++) {
            w3RemoveClass(x[i], "show");
            if ($(x[i]).hasClass(c)) w3AddClass(x[i], "show");
        }
    }

// Show filtered elements
    function w3AddClass(element, name) {
        var i, arr1, arr2;
        arr1 = element.className.split(" ");
        arr2 = name.split(" ");
        for (i = 0; i < arr2.length; i++) {
            if (arr1.indexOf(arr2[i]) == -1) {
                element.className += " " + arr2[i];
            }
        }
    }

// Hide elements that are not selected
    function w3RemoveClass(element, name) {
        var i, arr1, arr2;
        arr1 = element.className.split(" ");
        arr2 = name.split(" ");
        for (i = 0; i < arr2.length; i++) {
            while (arr1.indexOf(arr2[i]) > -1) {
                arr1.splice(arr1.indexOf(arr2[i]), 1);
            }
        }
        element.className = arr1.join(" ");
    }

// Add active class to the current button (highlight it)
    var btns = $("#arts-btn .btn-ul");
    for (var i = 0; i < btns.length; i++) {
        $(btns[i]).click(function () {

            filterSelection($(this).attr("category"))
            var current = $("#arts-btn .btn-gradient-no-width");
            current.removeClass('btn-gradient-no-width')
            $(this).addClass("btn-gradient-no-width");
        });
    }
})
