
$('document').ready(function () {

    var arts;
    var win = $(window);
    var colmn_number = 1;
    var sizes = [800,1200,1600]
    var w = win.width()
    sizes.forEach(function (v,k) {
        if(v <= w){
            colmn_number = k +2;
        }
    })
    var tmp = colmn_number;
    photo_res()
    function photo_res(){
        $('.colmn').addClass('remove')
        $.each($('.column'),function () {
            arts = $(this.getElementsByClassName('art-con'))
            arts.remove()
            let i;

            for(i = 0 ; i< colmn_number; i++){
                let col = document.createElement('div')
                //col.class = 'colmn';
                col = $(col);
                col.addClass('colmn');
                col.css('width',Math.floor(100/colmn_number).toString()+'%')
                let j;
                let index = 0;
                for(j = 0; j< arts.length;j++){
                    index = j% colmn_number
                    if( index === i){
                        col.append(arts[j])
                    }
                }

                $(this).children('ul').append(col)
            }
        })
        $('.remove').remove()
    }

    $(window).resize(function () {

        var w = win.width()
        colmn_number = 1;
        sizes.forEach(function (v,k) {
            if(v <= w){
                colmn_number = k +2;
            }
        })
        if(tmp !== colmn_number){
            photo_res()
            tmp = colmn_number;
        }

    });
    $('button[dclick]').click(function () {
        bookmark($(this).attr('dclick'))

    })
    function bookmark(url) {

        $.ajax({
            type: 'GET',
            url: url,
            success: function (data) {
                console.log(data);
            }
        });

    }
})

