<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    public function arts(){
        return $this->hasMany(Art::class);
    }
    public function questions(){
        return $this->hasManyThrough(Question::class,Art::class);
    }
    public function orders(){
        return $this->hasManyThrough(Order::class,Art::class);
    }

}
