<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['name','answers','order_image','status'];
    public function user(){
        return $this->belongsTo(User::class);
    }
    public function art(){
        return $this->belongsTo(Art::class);
    }
    public function answers(){
        return $this->hasMany(Answer::class);
    }
}
