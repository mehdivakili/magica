<?php

namespace App\Http\Controllers;

use App\Art;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function showUserType()
    {
        return view('panel.update_account');
    }

    public function bookmark(Art $art)
    {
        $user = Auth::user();
        $bookmarks = json_decode($user->bookmarks,true);
        if (isset( $bookmarks[$art->id])) {
            unset($bookmarks[$art->id]);
        } else {
            $bookmarks[$art->id] = $art->id;
        }
        $user->bookmarks = json_encode($bookmarks);
        $user->save();

        return "successfully saved";

    }
    public function update(Request $request)
    {
        $user = Auth::user();
        $request->validate([
           'name' => 'required|min:4',
           'phone_number'=>'required|string|min:10|max:12|regex:/[0-9]{9}/|unique:users,id,'.$user->id,
           'email'=>'sometimes|required|email|unique:users,id,'.$user->id
        ]);

        $user->name = $request->input('name');
        $user->phone_number = $request->input('phone_number');
        $user->email = $request->input('email');
        $user->save();
        return redirect()->back();
    }
}
