<?php

namespace App\Http\Controllers;

use App\Answer;
use App\Art;
use App\Category;
use App\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function index()
    {
        return view('panel.arts', ['categories' => Category::all(), 'js' => ['photo','photo-btn']]);
    }
    public function show_saves(){
        return view('panel.arts',['js' => ['photo']]);
    }

    public function create(Request $request, Art $art)
    {
        $qs = [];
        foreach ($art->questions as $q) {
            $qs[$q->title] = 'required';
        }

        $request->validate(
            $qs
        );
        $order = new Order();
        $order->status = "not completed";
        $order->name = $art->category->name . ' ' . $art->title;
        $order->user_id = Auth::user()->id;
        $order->art_id = $art->id;
        //$order->answers = json_encode($request->all());
        $order->order_image = '';
        $order->save();
        foreach ($art->questions as $q) {
            $a = new Answer();
            $a->question_id = $q->id;
            $a->order_id = $order->id;
            $a->value = $request->input($q->title);
            $a->save();
        }

        return redirect()->back();
    }

    public function create_show(Art $art)
    {
        return view('panel.art', ['art' => $art, 'js' => ['create_order']]);
    }

    public function export(Category $category)
    {
        $excel = '';
        $instance = [];
        $data = [];
        $instance['name'] = 'XXX';
        foreach ($category->questions as $q) {
            if ($q->type = 'file')
                $instance[$q->title] = 'XXX.jpg';
            else
                $instance[$q->title] = 'XXX';
        }
        foreach ($category->arts as $art){
            $instance[$art->name] = 'FALSE';
        }
        foreach ($category->orders as $order) {
            $cp = $instance;
            $cp['name'] = $order->user_id . '_' . $order->id;

            foreach ($order->answers as $answer) {
                $cp[$answer->question->title] = $answer->value;
            }
            $cp[$order->art->name] = 'TRUE';
            $data[] = $cp;

        }



        $flag = false;
        foreach ($data as $row) {
            if (!$flag) {
                // display field/column names as first row
                $excel .= implode("\t", array_keys($row)) . "\r\n";
                $flag = true;
            }
            $excel .= implode("\t", array_values($row)) . "\r\n";
        }


       return response($excel,200)->header('Content-Type', 'text/plain');

    }
    function showSaves(){
        $bookmarks = (array) json_decode(Auth::user()->bookmarks);
        $arts = Art::find($bookmarks);
        return view('panel.bookmarks',['arts'=>$arts,'js'=>['photo']]);
    }

}
