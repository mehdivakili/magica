$(document).ready(function () {
    $.each($('img'),function () {
        if($(this).width()/$(this).height() > $('.image-bg').width()/$('.image-bg').height()){
            $(this).css("width","100%")
        }else {
            $(this).css("height","100%")
        }
        $(window).resize(function () {
            $.each($('img'),function () {
                if ($(this).width() / $(this).height() > $('.image-bg').width() / $('.image-bg').height()) {
                    $(this).css("width", "100%")
                    $(this).css("height","")
                } else {
                    $(this).css("height", "100%")
                    $(this).css("width","")
                }
            })
        })
    })
})
