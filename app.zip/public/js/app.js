$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});


$('document').ready(function () {



    var heightSetter = $('.available')
    var minHeight = parseInt($('.panel-menu').css('min-height').slice(0,-2) )
    var fh = heightSetter.height()
    if($('body').height() >= minHeight - 40) {
        heightSetter.height(fh + $('.body').height() - $('#panel-app').height())
        //heightSetter.height(fh + $('.body').height() - $('#panel-app').height())
    }

    if(res.length !== 0){

        res.forEach(function (v) {
            $("."+v['source']).height($("."+v['dest']).height() + v['px']);
            $("."+v['source']+" ul").height($("."+v['dest']).height() + v['px'] -v["ul_px"])
        })
    }
    $(window).resize(function() {
        // $('.account-div').height($('.account-div').width())
        if($('body').height() > minHeight) {
            heightSetter.height(heightSetter.height() + $('body').height() - $('#panel-app').height())
        }
        if(res.length !== 0){
        res.forEach(function (v) {
            $("."+v['source']).height($("."+v['dest']).height() + v['px']);
            $("."+v['source']+" ul").height($("."+v['dest']).height() + v['px'] -v["ul_px"])
        })
        }
    })


});
