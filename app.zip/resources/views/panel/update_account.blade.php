@extends('layouts.app')
@section('content')
    <div class="account-panel">
        <div class="basic style-div banners">
            <div class="style-div-extra">
                <div class="style-div title">

                    <span>{{__('Basic')}}</span>
                </div>
            </div>
            <div class="style-div-extra"><p class="style-div description">{{__('Monthly')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">۹۰ {{__('daily order')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">{{__('Without')}} {{__('mail system')}}</p>
            </div>
            <div class="style-div-extra"><p class="style-div description">{{__('With')}} {{__('ads')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">{{__('Access to VIP design')}}</p></div>
            <div class="style-div-extra">
                <div class="style-div cost">
                    <p><span>{{__('25,000')}}</span> {{__("Toman")}}</p>
                </div>
            </div>
            <a class="btn btn-gradient">{{__("Activate")}}</a>

        </div>
        <div class="general style-div banners">
            <div class="style-div-extra">
                <div class="style-div title">
                    <span>{{__('General')}}</span>
                </div>
            </div>
            <div class="style-div-extra"><p class="style-div description">{{__('Monthly')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">۱۵۰ {{__('daily order')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">{{__('With')}} {{__('mail system')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">{{__('Without')}} {{__('ads')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">{{__('Access to VIP design')}}</p></div>
            <div class="style-div-extra">
                <div class="style-div cost">
                    <p><span>{{__('50,000')}}</span> {{__("Toman")}}</p>
                </div>
            </div>
            <a class="btn btn-gradient">{{__("Activate")}}</a>

        </div>
        <div class="advanced style-div banners">
            <div class="style-div-extra">
                <div class="style-div title">
                    <span>{{__('Advanced')}}</span>
                </div>
            </div>
            <div class="style-div-extra"><p class="style-div description">{{__('Monthly')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">۳۶۰ {{__('daily order')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">{{__('With')}} {{__('mail system')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">{{__('Without')}} {{__('ads')}}</p></div>
            <div class="style-div-extra"><p class="style-div description">{{__('Access to VIP design')}}</p></div>
            <div class="style-div-extra">
                <div class="style-div cost">
                    <p><span>{{__('100,000')}}</span> {{__("Toman")}}</p>
                </div>
            </div>
            <a class="btn btn-gradient">{{__("Activate")}}</a>
        </div>
    </div>

    </div>
@stop
