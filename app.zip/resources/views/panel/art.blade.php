@extends('layouts.app')
@section('content')
    <div class="order-panel">

        @include('widget.div-style-start',['title'=>__("Personalizing order"), 'classes'=>'form'])
        <form method="post" action="./{{$art->name}}">
            @csrf
            @foreach($art->questions as $q)
                @include('widget.questions.'.$q->type,['name'=>$q->title,"ph"=>$q->title])
            @endforeach
            <div class="form-group d-flex justify-content-end">
                <a class="btn btn-gray" style="margin-left: 20px; width: 130px" href="{{url('arts')}}">{{__("Cancel")}}</a>
                <button type="submit" style="width: 130px" class="btn btn-gray">{{__("Submit order")}}</button>
            </div>
        </form>

        @include('widget.div-style-end')
        <div class="image-bg available">
            <img class="after-image" src="{{furl($art->after_image_link)}}">
            <img class="pro-image" src="{{furl($art->pro_image_link)}}">

        </div>
    </div>
@stop

