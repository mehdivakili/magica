@extends('layouts.app')
@section('content')
    @include('widget.div-style-start',['classes'=>'art-panel available','style'=>'min-height: 555px'])
    @empty($categories)
        <p>asdfjkadjfla</p>
    @else
        <ul id="arts-btn" class="d-flex row">

            @foreach($categories as $category)

                <li class="style-div btn btn-ul" @if($loop->first) first
                    @endif category="{{$category->slug}}">{{$category->name}}</li>
            @endforeach
        </ul>

        @foreach($categories as $category)
            @include('widget.div-style-scroll-start',['classes'=>'column '.$category->slug,'height_depend'=>'available','height_px'=>-53, 'bg'=>'#00000000', 'info'=>false,'name'=>'column'])
            <ul >

                @foreach($category->arts as $art)
                    <li class="art-con">
                        <a href="{{url('art/'.$art->name)}}">
                            <img class="img-fluid" src="{{furl($art->pro_image_link)}}">
                        </a>
                        <div class="banner-content" href="{{url('art/'.$art->name)}}">
                            <a href="{{url('art/'.$art->name)}}" style="position: absolute; width: 100%;height: 100%; top: 0; left: 0"></a>
                            <button class="icon" onclick="bookmark('{{url('bookmark/'.$art->name)}}')">@include('svg.bookmark-white')</button>
                        </div>
                    </li>
                @endforeach
            </ul>
            @include('widget.div-style-end')
        @endforeach
    @endempty
    @include('widget.div-style-end')
<script>
    function bookmark(url) {
        $.ajax({
            type: 'GET',
            url: url,
            success: function (data) {
            }
        });

    }
</script>
@stop
