<div class="style-div-scroll {{$classes ?? '' ?? ''}}" style="@if(!empty($bg))background-color:{{$bg}}; border-radius: 0; padding:0; {{$style??''}}  @endif">
    <div class="justify-content-between row" style="margin: 0; position: relative; padding-left: 20px">

        @if(!empty($title))<p>{{ $title}}</p>@endif
        @if($info ?? '' !== false)<div class="info-icon @if(empty($title)) abs-info @endif">@include('svg.info')</div>@endif
    </div>
    @empty($height_depend)
    @else
    <script defer>
        toRes("{{$name ?? $classes ?? ''}}","{{$height_depend}}",{{$height_px}},@empty($title)0 @endempty)


    </script>
    @endempty

