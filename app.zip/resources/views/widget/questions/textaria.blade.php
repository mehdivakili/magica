<div class="form-group">
    <textarea class="form-control" name="{{$name}}" placeholder="{{$ph}}"></textarea>
</div>
