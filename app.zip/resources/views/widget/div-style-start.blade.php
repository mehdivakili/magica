<div class='style-div {{$classes ?? ''}}' style="{{$style??''}}">
    <div class="justify-content-between row" style="margin: 0;padding: 0; position: relative;">

        @if(!empty($title))<p>{{ $title}}</p>@endif
        <div class="info-icon @if(empty($title)) abs-info @endif">@include('svg.info')</div>
    </div>




