<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 179.02 188">
    <defs>
        <style>.cls-7 {
                fill: #333;
            }

            .cls-5 {
                fill: url(#New_Gradient_Swatch_10);
            }

            .cls-6 {
                fill: url(#New_Gradient_Swatch_10-2);
            }</style>
        <linearGradient id="New_Gradient_Swatch_10" x1="161.1" x2="161.1" y2="188" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#92278f"/>
            <stop offset="0.2" stop-color="#8f2a91"/>
            <stop offset="0.37" stop-color="#853398"/>
            <stop offset="0.52" stop-color="#7443a3"/>
            <stop offset="0.66" stop-color="#5c59b2"/>
            <stop offset="0.8" stop-color="#3d75c7"/>
            <stop offset="0.93" stop-color="#1898df"/>
            <stop offset="1" stop-color="#00aeef"/>
        </linearGradient>
        <linearGradient id="New_Gradient_Swatch_10-2" x1="17.92" y1="0" x2="17.92" y2="188"
                        xlink:href="#New_Gradient_Swatch_10"/>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home_P" data-name="Home P">
            <path class="cls-7"
                  d="M89.51,188A17.91,17.91,0,0,1,73.3,177.71L1.71,25.54A17.91,17.91,0,0,1,34.13,10.29L89.51,128,144.89,10.29a17.91,17.91,0,0,1,32.42,15.25L105.72,177.71A17.92,17.92,0,0,1,89.51,188Z"/>
            <path class="cls-5"
                  d="M161.1,188a17.91,17.91,0,0,1-17.92-17.91V17.92a17.92,17.92,0,1,1,35.83,0V170.09A17.91,17.91,0,0,1,161.1,188Z"/>
            <path class="cls-6"
                  d="M17.92,188A17.91,17.91,0,0,1,0,170.09V17.92a17.92,17.92,0,1,1,35.83,0V170.09A17.91,17.91,0,0,1,17.92,188Z"/>
        </g>
    </g>
</svg>
