<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.29 24.5">
    <defs>
        <style>.cls-234 {
                fill: white;
            }</style>
    </defs>
    <g id="Layer_21312" data-name="Layer 21312">
        <g id="Home_P" data-name="Home P">
            <path class="cls-234"
                  d="M15.3,24.5a1,1,0,0,1-.73-.33L8.15,17.09,1.73,24.17a1,1,0,0,1-1.09.26A1,1,0,0,1,0,23.5V1A1,1,0,0,1,1,0H15.3a1,1,0,0,1,1,1V23.5a1,1,0,0,1-.63.93.92.92,0,0,1-.36.07ZM8.15,14.61a1,1,0,0,1,.73.33l5.43,6V2H2V20.93l5.42-6a1,1,0,0,1,.74-.33Z"/>
        </g>
    </g>
</svg>
