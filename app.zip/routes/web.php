<?php

use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    App::setLocale('fa');
    return view('welcome');
});
Route::get('/aboutUs', function () {
    return view('aboutUs');
});

App::setLocale('fa');
//Route::group(array('before' => 'auth'), function(){
   Route::post('phone_number_verification',[ 'as' => 'phone_number_verification', 'uses' => 'HomeController@varify_phone_number_create']);
Route::get('phone_number_verification',[ 'as' => 'phone_number_verification', 'uses' =>'HomeController@varify_phone_number']);
   //Route::post('varify',[ 'as' => 'varify', 'uses' =>'HomeController@varify_phone_number']);
//});
Auth::routes();




Route::group(['prefix' => 'admin','locale'=>'en'], function () {
    //App::setLocale('en');
    Voyager::routes();

});
Route::group(['prefix' => 'admin','middleware' => 'admin.user'], function () {
    Route::get('/hello',function (){
        return "hello to admin";
    });
    Route::get('/export/{category:name}','OrderController@export');
});
Route::group(['middleware' => 'auth'], function () {
    //Route::get('/home', 'UserController@index')->name('home');
    Route::get('home','HomeController@index')->name('home');
    Route::post('editUser','UserController@update');
    Route::get('arts','OrderController@index')->name('arts');
    Route::get('art/{art:name}','OrderController@create_show')->name('art');
    Route::post('art/{art:name}','OrderController@create')->name('createorder');

    Route::get('editpicture/{order:title}','OrderController@sedit');
    Route::get('editpictures','OrderController@show_saves');
    Route::get('yourAds',function (){
        return view('ads');
    });
    Route::get('upgradeAccount','UserController@showUserType');
    Route::get('savedOrders','OrderController@showSaves');
    Route::get('tickets','TicketController@index');
    Route::post('createticket','TicketController@create')->name("createticket");
    Route::get('bookmark/{art:name}','UserController@bookmark');


});
