@extends('layouts.out',['page_title'=>'Verify'])

@section('content')


    @include('widget.div-style-start',['classes'=>'login-form offset-2','title'=> __('Verify Your Email Address'),'info'=>false ])
    @if (session('resent'))
        <div class="alert alert-success" role="alert">
            {{ __('A fresh verification link has been sent to your email address.') }}
        </div>
    @endif

    {{ __('Before proceeding, please check your email for a verification link.') }}
    {{ __('If you did not receive the email') }},
    <form class="d-inline" method="POST" action="{{ route('verification.resend') }}">
        @csrf
        <button type="submit" style="font-size: 12px; padding: 12px; margin-top: 1.1rem"
                class="btn btn-gradient p-0 m-0 align-baseline">{{ __('click here to request another') }}</button>
    </form>
    @include('widget.div-style-end')
@endsection
