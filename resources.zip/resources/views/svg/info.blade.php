<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26.55 26.55">
    <defs>
        <style>.cls-info {
                fill: gray;
            }</style>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home_P" data-name="Home P">
            <path class="cls-info"
                  d="M13.27,26.55A13.28,13.28,0,1,1,26.55,13.27,13.29,13.29,0,0,1,13.27,26.55ZM13.27,2A11.29,11.29,0,1,0,24.56,13.27,11.29,11.29,0,0,0,13.27,2Z"/>
            <path class="cls-1" d="M13.27,19.84a1,1,0,0,1-1-1v-6.7a1,1,0,1,1,2,0v6.7a1,1,0,0,1-1,1Z"/>
            <path class="cls-1" d="M14.68,8.43A1.41,1.41,0,1,1,13.27,7a1.41,1.41,0,0,1,1.41,1.41Z"/>
        </g>
    </g>
</svg>
