<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 32">
    <defs>
        <style>.cls-1-menubar {
                fill: none;
                stroke: #333;
                stroke-linecap: round;
                stroke-linejoin: round;
                stroke-width: 4px;
            }</style>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home">
            <line class="cls-1-menubar" x1="2" y1="16" x2="42" y2="16"/>
            <line class="cls-1-menubar" x1="2" y1="2" x2="42" y2="2"/>
            <line class="cls-1-menubar" x1="2" y1="30" x2="42" y2="30"/>
        </g>
    </g>
</svg>
