<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24.61 24.6">
    <defs>
        <style>.cls-66-123{fill:url(#New_Gradient_Swatch_66_123);}</style>
        <linearGradient id="New_Gradient_Swatch_66_123" y1="12.3" x2="24.61" y2="12.3" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#92278f"/>
            <stop offset="0.2" stop-color="#8f2a91"/>
            <stop offset="0.37" stop-color="#853398"/>
            <stop offset="0.52" stop-color="#7443a3"/>
            <stop offset="0.66" stop-color="#5c59b2"/>
            <stop offset="0.8" stop-color="#3d75c7"/>
            <stop offset="0.93" stop-color="#1898df"/>
            <stop offset="1" stop-color="#00aeef"/>
        </linearGradient>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home_P" data-name="Home P">
            <path class="cls-66-123"
                  d="M24.29,22.72,17.53,16a9.84,9.84,0,0,0-.74-13.08A9.84,9.84,0,0,0,0,9.83a9.83,9.83,0,0,0,16,7.69l6.76,6.76a1.07,1.07,0,0,0,.78.32,1.09,1.09,0,0,0,.78-.32A1.1,1.1,0,0,0,24.29,22.72Zm-8.47-8.15A7.63,7.63,0,0,1,2.21,9.83,7.64,7.64,0,0,1,15.92,5.21,7.67,7.67,0,0,1,15.82,14.57Z"/>
        </g>
    </g>
</svg>
