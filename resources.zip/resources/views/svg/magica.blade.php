<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 128 52.28">
    <defs>
        <style>.cls-magica {
                fill: white;
            }</style>
        <linearGradient id="linear-gradient" y1="26.14" x2="128" y2="26.14" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#92278f"/>
            <stop offset="0.2" stop-color="#8f2a91"/>
            <stop offset="0.37" stop-color="#853398"/>
            <stop offset="0.52" stop-color="#7443a3"/>
            <stop offset="0.66" stop-color="#5c59b2"/>
            <stop offset="0.8" stop-color="#3d75c7"/>
            <stop offset="0.93" stop-color="#1898df"/>
            <stop offset="1" stop-color="#00aeef"/>
        </linearGradient>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home_P" data-name="Home P">
            <path class="cls-magica"
                  d="M42.62,52.27H30A3.14,3.14,0,0,1,30,46H42.62a3.14,3.14,0,0,1,0,6.27ZM76.84,46A3.14,3.14,0,1,0,80,49.14,3.13,3.13,0,0,0,76.84,46ZM128,25a14.35,14.35,0,0,1-14.34,14.34,12.5,12.5,0,0,1-1.38-.07H15.72a12.5,12.5,0,0,1-1.38.07A14.35,14.35,0,0,1,0,25V3.2a3.2,3.2,0,0,1,6.4,0v10l1.53-1.1L23.94.65a3.13,3.13,0,1,1,3.65,5.09l-8.12,5.82A14.33,14.33,0,0,1,26.23,33H40a8,8,0,0,0,0-16,3.14,3.14,0,0,1,0-6.27A14.28,14.28,0,0,1,51.83,33h25a8,8,0,1,0-8-8,3.14,3.14,0,0,1-6.27,0,14.28,14.28,0,1,1,26.09,8h13.12A14.34,14.34,0,1,1,128,25ZM22.29,25A7.95,7.95,0,0,0,10.43,18a8.24,8.24,0,0,0-1.36,1A7.94,7.94,0,1,0,22.29,25Zm99.31,0a7.95,7.95,0,1,0-7.94,7.94A8,8,0,0,0,121.6,25Z"/>
        </g>
    </g>
</svg>
