<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 5.2 9.4">
    <defs>
        <style>.cls-arrow-right{fill:none;stroke:#333;stroke-linecap:round;stroke-linejoin:round;}</style>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home_P_copy" data-name="Home P copy">
            <polyline class="cls-arrow-right" points="0.5 8.9 4.7 4.7 0.5 0.5"/>
        </g>
    </g>
</svg>
