<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13.03 19.6">
    <defs>
        <style>.bookmark-fill{
                fill: #fff;
            }</style>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home_P" data-name="Home P">
            <path class="bookmark-fill"
                  d="M13,.79v18a.78.78,0,0,1-.51.74.71.71,0,0,1-.28.06.79.79,0,0,1-.59-.26L6.51,13.67,1.38,19.34a.79.79,0,0,1-.87.2A.78.78,0,0,1,0,18.8V.79A.79.79,0,0,1,.79,0H12.24A.79.79,0,0,1,13,.79Z"/>
        </g>
    </g>
</svg>
