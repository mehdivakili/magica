<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9.4 9.4">
    <defs>
        <style>.cls-1-cancel {
                fill: none;
                stroke: #333;
                stroke-linecap: round;
                stroke-linejoin: round;
            }</style>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Home_P" data-name="Home P">
            <line class="cls-1-cancel" x1="0.5" y1="0.5" x2="8.9" y2="8.9"/>
            <line class="cls-1-cancel" x1="8.9" y1="0.5" x2="0.5" y2="8.9"/>
        </g>
    </g>
</svg>
