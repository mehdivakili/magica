@php $id =rand()@endphp
{{--<style>
    input[type="file"] {
        display: none;
    }
    .custom-file-upload-2 {
        border: 1px solid #ccc;
        display: inline-block;
        padding: 6px 12px;
        cursor: pointer;
    }
</style>
<div class="form-group">
    <label for="{{$id}}" class="custom-file-upload-2">
        <i class="fa fa-cloud-upload"></i> {{$ph}}
    </label>
    <input id="{{$id}}" type="file" name="{{$name}}"/>
</div>--}}

<div class="custom-file">
    <input type="file" class="custom-file-input" id="{{$id}}" name="{{$name}}" required>
    <label class="custom-file-label" for="{{$id}}">{{$ph}}</label>
</div>
<script>
    $('#{{$id}}').on('change',function(){
        //get the file name
        var fileName = $(this).val();
        //replace the "Choose a file" label
        $(this).next('.custom-file-label').html(fileName);
    })
</script>
