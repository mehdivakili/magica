@extends('layouts.app',['page_title'=>'Personalizing order'])
@section('content')
    <div class="order-panel">

        @include('widget.div-style-scroll-start',['title'=>__("Personalizing order"), 'classes'=>'form','description'=>description('art')])
        <ul>
            <form method="post" action="{{route('createorder',[$art])}}" enctype="multipart/form-data">
                @csrf
                @foreach($art->questions as $q)
                    @include('widget.questions.'.$q->type,['name'=>$q->name,"ph"=>$q->title])
                @endforeach
                <div class="form-group d-flex justify-content-end">
                    <a class="btn btn-gray" style="margin-left: 20px; width: 130px"
                       href="{{route('arts')}}">{{__("Cancel")}}</a>
                    <button id="form_submin_button" data-id="{{$art->id}}" type="button" style="width: 130px"
                            class="btn btn-gray">{{__("Submit order")}}</button>

                </div>

            </form>
        </ul>
        @include('widget.div-style-end')
        <div class="image-bg available">
            <img class="after-image" src="{{furl($art->after_image_link)}}">
            <img class="pro-image" src="{{furl($art->pro_image_link)}}">
            <p class="img-description">{{$art->description}}</p>
            <span class="style-div-extra"><span class="btn-gray btn-preview"> {{__("Preview")}}</span></span>

        </div>
    </div>
@stop

